export class Constants {
    public static success = 'success'
    public static failure = 'failure'
}