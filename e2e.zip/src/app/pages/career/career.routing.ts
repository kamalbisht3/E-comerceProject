import { Routes } from '@angular/router';
import { CareerComponent } from './career.component';

export const CareerRoutes: Routes = [
  { path: '', component: CareerComponent }
];

