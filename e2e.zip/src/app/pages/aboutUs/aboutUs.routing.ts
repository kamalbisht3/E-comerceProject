import { Routes } from '@angular/router';
import { AboutUsComponent } from './aboutUs.component';

export const aboutUsRoutes: Routes = [
  { path: '', component: AboutUsComponent },
];
