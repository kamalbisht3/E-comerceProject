import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ethicalTrading',
  templateUrl: './ethicalTrading.component.html',
  styleUrls: ['./ethicalTrading.component.scss']
})
export class EthicalTradingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
