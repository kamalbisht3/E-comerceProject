import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deliveryInformation',
  templateUrl: './deliveryInformation.component.html',
  styleUrls: ['./deliveryInformation.component.scss']
})
export class DeliveryInformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
