import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'product-sizeChart',
  templateUrl: './sizeChart.component.html',
  styleUrls: ['./sizeChart.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SizeChartComponent implements OnInit {

  constructor() {

  }

  ngOnInit() {
  }

}
