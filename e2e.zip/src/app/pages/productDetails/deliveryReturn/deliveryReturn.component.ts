import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';



@Component({
  selector: 'app-deliveryReturn',
  templateUrl: './deliveryReturn.component.html',
  styleUrls: ['./deliveryReturn.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DeliveryReturnComponent implements OnInit {

  constructor() { }
 
  ngOnInit() {
  }

}
