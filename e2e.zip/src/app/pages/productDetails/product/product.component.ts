import { ProductDetailsService } from './../productDetails.service';
import { Component, NgZone, ApplicationRef } from '@angular/core';
import { Cart } from '../../../store/cart.store';
import { UserService } from '../../../services/user.service';
import { Constants } from '../../../api/constants';
import { SharedDataService } from '../../../services/shareData.service';
import { ActivatedRoute, Router } from '@angular/router';
import { containerStart } from '@angular/core/src/render3/instructions';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LoginComponent } from '../../login/login.component';
import { LocalStorage } from 'ngx-webstorage';
import { DatePipe } from '@angular/common';
declare var $: any;

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent {

  progress: number = 0;
  label: string;
  productDetails: any;
  localCart: any = [];
  localWishList: any = [];
  localPCRData: any = [];
  Quantity: number = 1;
  productId: any;
  localAddcartList: any;
  localAddwishList: any;
  galleryImages = <any>[];
  ColorList = <any>[];
  SizeList= <any>[];
  _ColorList = <any>[];
  _SizeList= <any>[];
  defaultColor : string;
  defaultSize: string;
  defaultWishlistColor : string;
  defaultWishlistSize: string;
  _ColorWishListResponse = <any>[];
  _SizeWishListResponse= <any>[];
    _ColorListResponse = <any>[];
  _SizeListResponse= <any>[];
  defaultColorResponse : string;
  defaultSizeResponse: string;
  UserCartList=<any>[];
  id : any;
  price: any;
  name: any;
  thumbnail: any;
  created_at:any;
  onSale:any;
  stockAmount:any;
  sku:any;
  discount:any;
  description:any;
  qty: any;
  totallength: number =0;
  UserProductList = <any>[];
  AddCartForUserList = <any>[];
  variation_id: string;
  public userReviewDetails: any = [];
  reviewCount: number; totalReviews: number;
  fiveStar: any = []; fourStar: any = []; threeStar: any = [];
  oneStar: any = []; avgStar: number; twoStar: any = []
  fiveStarCount: number; fourStarCount: number; threeStarCount: number;
  twoStarCount: number; oneStarCount: number; userDetail: any; avgStarCount: any;
  addToWishListForUser = <any>[];
  addToWishListResponse = <any>[];
  variationId: string;
  WishListLength: number;
  user: any;
  wishList =<any>[];
  AfterAddToCart = <any>[];
  SubstringSizeList= <any>[];
  sizeList = <any>[];
  selectedSize: string;
  selectedColor: string;
  selectedThumbnail: string;
  defaultThumbnail: string;
  isSize: boolean;
  _UserCartList =<any>[];
  constructor(public applicationRef: ApplicationRef,private datePipe: DatePipe,
    private _ngZone: NgZone,
    private cart: Cart,
    private sharedDataService: SharedDataService,
    private userService: UserService,
    public activatedRoute: ActivatedRoute,
    public router: Router,
    private modalService: NgbModal,
    public productDetailsService: ProductDetailsService) {
      debugger;
    this.productDetails = this.productDetailsService.productDetails;
    this.productDetailsService.productDetailsSubject.subscribe((data) => {
      debugger;
      this.productDetails = null;
      this.selectedThumbnail='';
      this.selectedSize='';
      this.selectedColor='';
      this.sizeList =[];
      this.isSize = false;
      debugger;
      this.productDetails = this.productDetailsService.productDetails;
      this.GetProductSizeList( this.productDetails);
      // localStorage.setItem('ProductCollection', JSON.stringify(this.productDetails))
      this.Quantity = 1;
      this.ColorList = [];
    });
  }
  ngOnInit() {
    debugger;
    this.isSize = false;
  // const ProductCollection= JSON.parse(localStorage.getItem('ProductCollection'));
   this.GetProductSizeList(this.productDetails);
    this.userDetail = JSON.parse(localStorage.getItem('user'))
    this.activatedRoute.params.subscribe((data) => {
      this.productId = data['id'];
    this.userService.getUserReview(this.productId).subscribe((res: any) => {
      if (res.status == Constants.success) {
        this.userReviewDetails = res.data;
        this.reviewCount = this.userReviewDetails.data.length;
        for (var i = 0; i < this.userReviewDetails.data.length; i++) {
    
          if (this.userReviewDetails.data[i].rating == 5) {
            this.fiveStar.push(this.userReviewDetails.data[i].rating);
          }
          else if (this.userReviewDetails.data[i].rating == 4) {
            this.fourStar.push(this.userReviewDetails.data[i].rating);
          }
          else if (this.userReviewDetails.data[i].rating == 3) {
            this.threeStar.push(this.userReviewDetails.data[i].rating);
          }
          else if (this.userReviewDetails.data[i].rating == 2) {
            this.twoStar.push(this.userReviewDetails.data[i].rating);
          }
          else if (this.userReviewDetails.data[i].rating == 1) {
            this.oneStar.push(this.userReviewDetails.data[i].rating);
          }
        
        }
        this.fiveStarCount = this.fiveStar.length;
        this.fourStarCount = this.fourStar.length;
        this.threeStarCount = this.threeStar.length;
        this.twoStarCount = this.twoStar.length;
        this.oneStarCount = this.oneStar.length;
        this.totalReviews = this.userReviewDetails.data.length;
        this.avgStarCount = Math.round((this.fiveStarCount * 5 + this.fourStarCount * 4 + this.threeStarCount * 3 + this.twoStarCount * 2 + this.oneStarCount * 1) / this.totalReviews );
            if(this.avgStarCount > 0){
              this.avgStar = this.avgStarCount;
            } else {
              this.avgStar = 0;    // Bcoz here avgStar return NaN .
            }
           }
       })
    })
   this.getWishListData();
   this.selectedThumbnail='';
   this.selectedSize='';
   this.selectedColor='';
  }

  getWishListData(){
    if(localStorage.getItem('user')) {
      this.user = JSON.parse(localStorage.getItem('user'))
      if(this.user.role == 'guest' && localStorage.getItem('wishlist|' + this.user.session_id)) {
        this.wishList = JSON.parse(localStorage.getItem('wishlist|' + this.user.session_id));
        this.WishListLength = this.wishList.length;
        this.cart.wishListData = this.wishList
        // console.log(this.cart.wishListData);
      } else {
        this.getWishList()
      }
    }
  }

  getWishList() {
    debugger;
    // after wishlist is add to cart
    this.AfterAddToCart = JSON.parse(localStorage.getItem('wishlistData'));
    if(this.AfterAddToCart !== null){
      this.wishList= [];
      for(let i =0 ; i<this.AfterAddToCart.length; i++){
      this.wishList.push({ product_id: this.AfterAddToCart[i].product_id,
        id: this.AfterAddToCart[i].id,
        thumbnail:this.AfterAddToCart[i].thumbnail,
        name:this.AfterAddToCart[i].name,
        price:this.AfterAddToCart[i].price,
        Color: this.AfterAddToCart[i].Color ,
        Size: this.AfterAddToCart[i].Size ,
        sku:this.AfterAddToCart[i].sku,
        variation_id:this.AfterAddToCart[i].variation_id,
        created_at: this.datePipe.transform(this.AfterAddToCart[i].created_at, 'mediumDate')
      });
    }
    this.WishListLength = this.wishList.length;
    this.cart.wishListData =this.wishList;
    // local storage is used when add data to AddToCart
    localStorage.setItem('wishlistData' , JSON.stringify(this.wishList));
    } else{
    this.userService.getWishList().subscribe((response: any) => {
      if(response.status == Constants.success) {
         debugger;
      //  this.wishList = response.data
        this.addToWishListResponse =  response.data;
        this.wishList= [];
        for(let i =0 ; i<this.addToWishListResponse.length; i++){
        this.GetColorSizeForWishListUser(this.addToWishListResponse[i]);
        if(this._ColorWishListResponse.length > 0){
          // get default color
          this.defaultWishlistColor = this._ColorWishListResponse[0].Color;
        }
        if(this._SizeWishListResponse.length > 0){
          // get default Size
          this.defaultWishlistSize = this._SizeWishListResponse[0].Size;
        }         
         this.wishList.push({ product_id: this.addToWishListResponse[i].product_id,
          id: this.addToWishListResponse[i].product_id,
          thumbnail:this.addToWishListResponse[i].products.thumbnail,
          name:this.addToWishListResponse[i].products.name,
          price:this.addToWishListResponse[i].variations.price,
          Color: this.defaultWishlistColor ,
          Size: this.defaultWishlistSize ,
          sku:this.addToWishListResponse[i].variations.sku,
          variation_id:this.addToWishListResponse[i].variations.id,
          created_at: this.datePipe.transform(this.addToWishListResponse[i].products.created_at, 'mediumDate')
        });
      }
        this.WishListLength = this.wishList.length;
        this.cart.wishListData =this.wishList;
        // local storage is used when add data to AddToCart
        localStorage.setItem('wishlistData' , JSON.stringify(this.wishList));
      }
    });
  }
  }

  galleryImage(){
    debugger;
    for(let i=0 ; i< this.productDetails.gallery.length ; i++){
      if(this.productDetails.gallery.length > 0) {
        debugger;
        this.galleryImages.push(this.productDetails.gallery[i].image)
      }
    }
  }
  changeZoomImage(imagePath) {
    this.productDetails.thumbnail = imagePath;
    this.applicationRef.tick();
  }




  GetProductColorList(productDetail) {
    this.ColorList = [];
    for (let i = 0; i < productDetail.variations.length; i++) {
      for (let j = 0; j < productDetail.variations[i].variant_options.length; j++) {
        if (productDetail.variants[0].id === productDetail.variations[i].variant_options[j].variant_id && productDetail.variants[0].type === 'color') {
          this.ColorList.push({ product_id: productDetail.variations[i].product_id, variationId: productDetail.variations[i].id, name: productDetail.variations[i].variant_options[j].name });
        }
      }
    }
  }

  GetProductSizeList(productDetail) {
    debugger;
    this.SizeList = [];
    for (let i = 0; i < productDetail.variations.length; i++) {
      for (let j = 0; j < productDetail.variations[i].variant_options.length; j++) {
        if (productDetail.variants[1].id === productDetail.variations[i].variant_options[j].variant_id && productDetail.variants[1].type === 'size') {
          this.SizeList.push({product_id: productDetail.variations[i].product_id, variationId: productDetail.variations[i].id, name: productDetail.variations[i].variant_options[j].name})
        }
      }
    }
  }
SelectedSize(size){
  debugger;
  this.selectedSize =size;
  this.isSize =true;
}
  getSize(currentSize){
    debugger;
    this.sizeList =[];
    for(let i= 0 ; i< this.SizeList.length; i++){
      debugger;
      const size = this.SizeList[i].name.substring(0,2);
      if(size=== currentSize.toString()){
      this.sizeList.push({Size:this.SizeList[i].name}); 
    }
    }
  }
 

  GetImageWithColor(colorname, variationId, product_id) {
    debugger;
    const GetVariantList = this.productDetails.variations.filter(val => val.product_id === product_id && val.id === variationId);
    if (GetVariantList[0].product_id != null && GetVariantList[0].id !== null) {
      this.productDetails.thumbnail = GetVariantList[0].image;
      this.productDetails.gallery = GetVariantList[0].variation_images;
      this.selectedColor = colorname;
      this.selectedThumbnail = GetVariantList[0].image;
      this.applicationRef.tick();
    }

  }

  IncrementValue(Quantity) {

    if (Quantity <= 9 && Quantity >= 1) {
      this.Quantity = this.Quantity + 1;
    }

  }
  DecrementValue(Quantity) {

    if (Quantity <= 10 && Quantity > 1) {
      this.Quantity = this.Quantity - 1;
    }
  }

  goToRoute(routePath?) {
    if (this.userDetail === null || this.userDetail.role === 'guest')
    {   
           const modalRef = this.modalService.open(LoginComponent)

    }
    if (routePath) {
      this.productId = JSON.parse(localStorage.getItem('productId'));
      this.router.navigateByUrl('/product-details/' + this.productId + '/' + routePath);
    } else {
      this.router.navigateByUrl('/product-details/' + this.productId);
    }
  }

  // listGallery(gallery) {
  //   debugger;
  //   gallery = gallery.map(function (element) {
  //     return element.thumbnail
  //   });
  //   return gallery
  // }

  // Loop inside the Angular zone
  // so the UI DOES refresh after each setTimeout cycle
  // processWithinAngularZone() {
  //   this.label = 'inside';
  //   this.progress = 0;
  //   this._increaseProgress(() => console.log('Inside Done!'));
  // }

  // // Loop inside the Angular zone
  // // so the UI DOES refresh after each setTimeout cycle
  processWithinAngularZone() {
    this.label = 'inside';
    this.progress = 0;
    this._increaseProgress(() => console.log('Inside Done!'));
    // console.log('Outside Doneasdfasdf!');
  }

  // // Loop outside of the Angular zone
  // // so the UI DOES NOT refresh after each setTimeout cycle
  processOutsideOfAngularZone() {
    this.label = 'outside';
    this.progress = 0;
    this._ngZone.runOutsideAngular(() => {
      this._increaseProgress(() => {
        // reenter the Angular zone and display done
        this._ngZone.run(() => {
          // console.log('Outside Done!');
        });
      });
    });
  }

  _increaseProgress(doneCallback: () => void) {
    this.progress += 1;
    // console.log(`Current progress: ${this.progress}%`);

    if (this.progress < 100) {
      // console.log('Outside Done!');
      window.setTimeout(() => this._increaseProgress(doneCallback), 10);
    } else {
      // console.log('Outside Done! 0000');
      doneCallback();
    }
  }

  ngAfterViewInit() {
    const colorLink: any = $('#colorLink');
    colorLink.click(function () {
      $('#colorObj').slideToggle();
    });

    $('#colorObj li').each(function () {
      $(this).click(function (e) {
        alert(e.target.children[0].title);
        console.dir(e.target.children[0].title);
      });
    });

    // $(".zoom_03").each(function () {
    //   var $this = $(this);
    //   var galery = $this.next().attr('id');
    //   $this.elevateZoom({
    //     gallery: galery,
    //     scrollZoom: "true",
    //     easing: "true",
    //     easingType: "zoomType",
    //     easingDuration: "2000",
    //     zoomType: "inner",
    //     cursor: "zoom-In",
    //     borderColour: "#eee",
    //     borderSize: "1",
    //     imageCrossfade: "true",
    //     zoomWindowFadeIn: "true",
    //     zoomWindowFadeOut: "true"
    //   })
    // });

    // $(".elevatezoom-gallery").on('click', function (e) {
    //   e.preventDefault();
    //   console.log("Item Clicked");
    //   $('.elevatezoom-gallery').removeClass('active');
    //   $(this).addClass('active');
    // });

    // document.getElementById("defaultOpen").click(); 



  }
  qtyAddToCart(productItem) {
    debugger;
    this.addToCart(productItem );
  }

  addToCart(productItem ) {
    debugger;
    let user = JSON.parse(localStorage.getItem('user'))
    if ((user && user.role == 'guest') || (this.cart.loginData && this.cart.loginData.role == 'guest')) {
      this.addCartForLocal(productItem)
    } else {
      this.GetColorSize(productItem);
      if(this._ColorList.length > 0){
        if(this.selectedColor !== null && this.selectedColor !== undefined && this.selectedColor !==''){
          //Selected Color
        this.defaultColor = this.selectedColor;
      } else {
        // get default color
        this.defaultColor = this._ColorList[0].name;
       }
      }
      if(this._SizeList.length > 0){
        if(this.selectedSize !== null && this.selectedSize !=='' && this.selectedSize !==undefined){
          //Selected Color
          this.defaultSize = this.selectedSize;
          }else{
        // get default Size
        this.defaultSize = this._SizeList[0].name;
          }
      }
      var obj = {
        "product_id": productItem.id,
        "variation_id": productItem.variations[0].id,
        "qty": this.Quantity,
        "Color":   this.defaultColor,
        "Size": this.defaultSize ,
        //  "donation": this.charity
       };
      this.addCartForUser(obj);
    }
    $('.shopping-cart-component').removeClass('hide');
  }

  addCartForUser(product) {
    this.userService.addCart(product).subscribe((response: any) => {
      debugger;
      this._UserCartList = JSON.parse(localStorage.getItem('UserCartList'));
      if (response.status == Constants.success) {
        this.userService.getCart().subscribe((response: any) => {
          if (response.status == Constants.success) {
            debugger;
            this.AddCartForUserList= response.data;
            for(let i =0 ; i<this.AddCartForUserList.length; i++){
              debugger
            if(this._UserCartList === null || this._UserCartList === 0){
              debugger;
              const counter =1;
              this.GetColorSizeForUser(this.AddCartForUserList[i]);
              if(this._ColorListResponse.length > 0){
                if(this.selectedColor !== null && this.selectedColor !== undefined && this.selectedColor !==''){
                  //Selected Color
                this.defaultColorResponse = this.selectedColor;
              } else {
                // get default color
                this.defaultColorResponse = this._ColorListResponse[0].Color;
                }
              }
              if(this._SizeListResponse.length > 0){
                if(this.selectedSize !== null && this.selectedSize !=='' && this.selectedSize !==undefined){
                  //Selected Color
                  this.defaultSizeResponse = this.selectedSize;
                  }else{
                // get default Size
                this.defaultSizeResponse = this._SizeListResponse[0].Size;
                  }
              }
              if(this.selectedThumbnail !== null && this.selectedThumbnail !== undefined && this.selectedThumbnail !=='' ){
              this.defaultThumbnail = this.selectedThumbnail;
              }else{
               this.defaultThumbnail= this.AddCartForUserList[i].products.thumbnail;
              }   
               this.UserCartList.push({
                 "product_id" :this.AddCartForUserList[i].product_id,
                 "variation_id": this.AddCartForUserList[i].variation_id ,
                "products": {
                  "name": this.AddCartForUserList[i].products.name,
                  "product_id": this.AddCartForUserList[i].product_id,
                  "thumbnail": this.defaultThumbnail,
                  "Color": this.defaultColorResponse,
                  "Size":this.defaultSizeResponse,
                  "description": this.AddCartForUserList[i].products.description  ,
                  "discount": this.AddCartForUserList[i].products.discount ,
                  "onSale":this.AddCartForUserList[i].products.onSale,  
                  "stockAmount": this.AddCartForUserList[i].products.stockAmount ,
                  "created_at":  this.datePipe.transform(this.AddCartForUserList[i].products.created_at, 'mediumDate') 
                },
                "variations": {
                  "sku": this.AddCartForUserList[i].variations.sku,
                  "price": this.AddCartForUserList[i].variations.price,
                },
                // qty is used for no of product 
                "qty":this.AddCartForUserList[i].qty , 
                "Quantity" : counter
                // "donation": this.charity
              });
              this._UserCartList =[];
            }
            const uniqueData =  this._UserCartList.filter(obj => obj.product_id !== this.AddCartForUserList[i].product_id );
            if(uniqueData.length >0){
            const counter =1;
            this.GetColorSizeForUser(this.AddCartForUserList[i]);
            if(this._ColorListResponse.length > 0){
              if(this.selectedColor !== null && this.selectedColor !== undefined && this.selectedColor !==''){
                //Selected Color
              this.defaultColorResponse = this.selectedColor;
            } else {
              // get default color
              this.defaultColorResponse = this._ColorListResponse[0].Color;
              }
            }
            if(this._SizeListResponse.length > 0){
              if(this.selectedSize !== null && this.selectedSize !=='' && this.selectedSize !==undefined){
                //Selected Color
                this.defaultSizeResponse = this.selectedSize;
                }else{
              // get default Size
              this.defaultSizeResponse = this._SizeListResponse[0].Size;
                }
            }
            if(this.selectedThumbnail !== null && this.selectedThumbnail !== undefined && this.selectedThumbnail !=='' ){
            this.defaultThumbnail = this.selectedThumbnail;
            }else{
             this.defaultThumbnail= this.AddCartForUserList[i].products.thumbnail;
            }   
             this.UserCartList.push({
               "product_id" :this.AddCartForUserList[i].product_id,
               "variation_id": this.AddCartForUserList[i].variation_id ,
              "products": {
                "name": this.AddCartForUserList[i].products.name,
                "product_id": this.AddCartForUserList[i].product_id,
                "thumbnail": this.defaultThumbnail,
                "Color": this.defaultColorResponse,
                "Size":this.defaultSizeResponse,
                "description": this.AddCartForUserList[i].products.description  ,
                "discount": this.AddCartForUserList[i].products.discount ,
                "onSale":this.AddCartForUserList[i].products.onSale,  
                "stockAmount": this.AddCartForUserList[i].products.stockAmount ,
                "created_at":  this.datePipe.transform(this.AddCartForUserList[i].products.created_at, 'mediumDate') 
              },
              "variations": {
                "sku": this.AddCartForUserList[i].variations.sku,
                "price": this.AddCartForUserList[i].variations.price,
              },
              // qty is used for no of product 
              "qty":this.AddCartForUserList[i].qty , 
              "Quantity" : counter
              // "donation": this.charity
            });
            }  
           }
            this.cart.cartData =  this.UserCartList;
            this.sharedDataService.changeCart(this.UserCartList);
            localStorage.setItem('UserCartList', JSON.stringify(this.UserCartList))
          }
        });
      }
    });
  
  }

  addCartForLocal(productItem) {
    debugger;
    this.GetColorSize(productItem);
    if(this._ColorList.length > 0){
     
      if(this.selectedColor !== null && this.selectedColor !== undefined && this.selectedColor !==''){
          //Selected Color
        this.defaultColor = this.selectedColor;
      }else {
      // get default color
      this.defaultColor = this._ColorList[0].name;
      }
    }
    if(this._SizeList.length > 0){
      if(this.selectedSize !== null && this.selectedSize!=='' && this.selectedSize !==undefined){
        //Selected Color
        this.defaultSize = this.selectedSize;
        }else {
         // get default Size
          this.defaultSize = this._SizeList[0].name;
      }
    }
    if (this.Quantity > 1) {
      this.localAddcartList = {
        "products": {
          "name": productItem.name,
          "product_id": productItem.id,
          "thumbnail": productItem.thumbnail,
          "Color": this.defaultColor,
          "Size":this.defaultSize
          // "Color": productItem.default_variant_options[0].name,
          // "Size":productItem.default_variant_options[1].name,
        },
        "variations": {
          "id": productItem.variations[0].id,
          "sku": productItem.variations[0].sku,
          "price": productItem.variations[0].price,
        },
        "id": productItem.id,
        "qty": this.Quantity,
        "Quantity" : 1
        // "donation": this.charity
      }
    } else {
      this.localAddcartList = {
        "products": {
          "name": productItem.name,
          "product_id": productItem.id,
          "thumbnail": productItem.thumbnail,
          "Color": this.defaultColor,
          "Size":this.defaultSize
          // "Color": productItem.default_variant_options[0].name,
          // "Size":productItem.default_variant_options[1].name,
        },
        "variations": {
          "id": productItem.variations[0].id,
          "sku": productItem.variations[0].sku,
          "price": productItem.variations[0].price,
        },
        "id": productItem.id,
        "qty": 1,
        "Quantity" : 1
        // "donation": this.charity
      }
    }
    let user = JSON.parse(localStorage.getItem('user'))
    this.localCart = JSON.parse(localStorage.getItem(user.session_id))
    if (this.localCart == null) {
      localStorage.setItem(user.session_id, JSON.stringify([this.localAddcartList]))
    } else {
      let item = this.localCart.filter((data: any) => data.id == productItem.id)
      if (item.length > 0) {
        item[0].qty = item[0].qty + this.Quantity;
        let i = item[0]
        this.localCart = this.localCart.filter(value => value.id != productItem.id)
        this.localCart.push(i)
      } else {
        this.localCart.push(this.localAddcartList);
      }
      localStorage.setItem(user.session_id, JSON.stringify(this.localCart));
    }
    this.cart.cartData = JSON.parse(localStorage.getItem(user.session_id));
    this.sharedDataService.changeCart(JSON.parse(localStorage.getItem(user.session_id)));
   
  }

  addToWishList(product: any) {
    let user = JSON.parse(localStorage.getItem('user'))
    if ((user && user.role == 'guest') || (this.cart.loginData && this.cart.loginData.role == 'guest')) {
      this.addWishListForLocal(product)
    } else {
      this.addWishListForUser(product)
    }
  }

  GetColorSizeForUser(productDetail){
    this._ColorListResponse = [];
    this._SizeListResponse = [];
    for (let i = 0; i < productDetail.variations.variant_options.length; i++) {
      const uniqueSizeList=  this._SizeListResponse.filter(val => val.variant_id === productDetail.variations.variant_options[i].variant_id );
      if(uniqueSizeList.length === 0){
        if(this._SizeListResponse.length > 0){
          const uniqueColorList=  this._ColorListResponse.filter(val => val.variant_id === productDetail.variations.variant_options[i].variant_id );
          if(uniqueColorList.length === 0){
            this._ColorListResponse.push({variant_id:productDetail.variations.variant_options[i].variant_id,Color:productDetail.variations.variant_options[i].name });
          }
        } else {
          this._SizeListResponse.push({variant_id:productDetail.variations.variant_options[i].variant_id,Size:productDetail.variations.variant_options[i].name });
        }
       }
    }
  }

  GetColorSize(productDetail){
    this._ColorList = [];
    this._SizeList = [];
    for (let i = 0; i < productDetail.variations.length; i++) {
      for (let j = 0; j < productDetail.variations[i].variant_options.length; j++) {
        if (productDetail.variants[0].id === productDetail.variations[i].variant_options[j].variant_id && productDetail.variants[0].type === 'color') {
          this._ColorList.push({ product_id: productDetail.variations[i].product_id, variationId: productDetail.variations[i].id, name: productDetail.variations[i].variant_options[j].name });
        }else{
          this._SizeList.push({product_id: productDetail.variations[i].product_id, variationId: productDetail.variations[i].id, name: productDetail.variations[i].variant_options[j].name})
        // for size code make new array for size
        }
      }
    }
  }


  // home page add item to wishlist
  addWishListForLocal(product: any) {
    debugger;
    this.GetColorSize(product);
    if(this._ColorList.length > 0){
      // get default color
      this.defaultColor = this._ColorList[0].name;
    }
    if(this._SizeList.length > 0){
      // get default Size
      this.defaultSize = this._SizeList[0].name;
    }
    this.localWishList= [];
    if(product.id !== undefined){
      this.id= product.id;
    }else{
      this.id= '';
    }
     if(product.thumbnail!== undefined){
      this.thumbnail =  product.thumbnail ;
     }else {
      this.thumbnail ='';
     }
     if(product.name!== undefined){
      this.name =   product.name ;
     }else{
      this.name = '';
     }
     if(product.variations[0].price !== undefined){
      this.price = product.variations[0].price 
     }else{
      this.price =0;
     }
     if(product.created_at !== undefined){
     // this.datePipe.transform(product.created_at, 'yyyy-MM-dd'); 
       this.created_at =  this.datePipe.transform(product.created_at, 'mediumDate'); // product.created_at;
     }else {
       this.created_at = ''; 
     }
     if(product.variations[0].sku !== undefined){
      this.sku = product.variations[0].sku 
     }else{
      this.sku =0;
     }
     if(product.variations[0].id !== undefined){
      this.variationId = product.variations[0].id ;
     }else{
      this.variationId ='';
     }
    let user = JSON.parse(localStorage.getItem('user'))
    let ids = 'wishlist|' + user.session_id
    this.localWishList = JSON.parse(localStorage.getItem(ids))
    if (this.localWishList == null) {
      this.localWishList= [];
      this.localWishList.push({product_id: this.id,thumbnail:this.thumbnail,name:this.name,price:this.price
        , Color:this.defaultColor ,Size: this.defaultSize ,created_at: this.created_at, 
        sku: this.sku ,id:this.variationId });
     // localStorage.setItem(ids, JSON.stringify([product]));
      localStorage.setItem(ids, JSON.stringify(this.localWishList));
      this.localWishList = JSON.parse(localStorage.getItem(ids));
    } else {
       let item = this.localWishList.filter((data: any) => data.id == product.id);   
      if (item.length === 0) {
        this.localWishList.push({ product_id: this.id,thumbnail:this.thumbnail,name:this.name,price:this.price
           , Color:this.defaultColor ,Size: this.defaultSize , created_at: this.created_at, 
           sku: this.sku ,id:this.variationId});
       } 
      //else {
      // //  this.localWishList =[];
      //   this.localWishList.push({ product_id: this.id,id:this.id,thumbnail:this.thumbnail,name:this.name,price:this.price
      //     , Color:this.defaultColor ,Size: this.defaultSize});
      //   // this.localWishList.push({product, Color: this.defaultColor , Size: this.defaultSize});
      // }
      localStorage.setItem(ids, JSON.stringify(this.localWishList));
    }
    this.cart.wishListData = this.localWishList;
  }

  GetColorSizeForWishListUser(productDetail){
    this._ColorWishListResponse = [];
    this._SizeWishListResponse = [];
    for (let i = 0; i < productDetail.variations.variation_variant_options.length; i++) {
      const uniqueSizeList=  this._SizeWishListResponse.filter(val => val.variant_id === productDetail.variations.variation_variant_options[i].option.variant_id );
      if(uniqueSizeList.length === 0){
        if(this._SizeWishListResponse.length > 0){
          const uniqueColorList=  this._ColorWishListResponse.filter(val => val.variant_id === productDetail.variations.variation_variant_options[i].option.variant_id );
          if(uniqueColorList.length === 0){
            this._ColorWishListResponse.push({variant_id: productDetail.variations.variation_variant_options[i].option.variant_id,Color:productDetail.variations.variation_variant_options[i].option.name });
          }
        } else {
          this._SizeWishListResponse.push({variant_id: productDetail.variations.variation_variant_options[i].option.variant_id,Size: productDetail.variations.variation_variant_options[i].option.name });
        }
       }
    }
  }

  addWishListForUser(product: any) {
    debugger;
    let obj = {
      "product_id": product.id,
      "variation_id": product.variations[0].id,
    }
    this.userService.addToWishList(obj).subscribe((response: any) => {
      if (response.status == Constants.success) {
        this.userService.getWishList().subscribe((response: any) => {
          if (response.status == Constants.success) {
            debugger;
            this.addToWishListResponse = response.data;
            this.addToWishListForUser= [];
            for(let i =0 ; i<this.addToWishListResponse.length; i++){
            this.GetColorSizeForWishListUser(this.addToWishListResponse[i]);
            if(this._ColorWishListResponse.length > 0){
              // get default color
              this.defaultWishlistColor = this._ColorWishListResponse[0].Color;
            }
            if(this._SizeWishListResponse.length > 0){
              // get default Size
              this.defaultWishlistSize = this._SizeWishListResponse[0].Size;
            }         
             this.addToWishListForUser.push({ product_id: this.addToWishListResponse[i].product_id,
              id: this.addToWishListResponse[i].product_id,
              thumbnail:this.addToWishListResponse[i].products.thumbnail,
              name:this.addToWishListResponse[i].products.name,
              price:this.addToWishListResponse[i].variations.price,
              Color: this.defaultWishlistColor ,
              Size: this.defaultWishlistSize ,
              sku:this.addToWishListResponse[i].variations.sku,
              variation_id:this.addToWishListResponse[i].variations.id,
              created_at: this.datePipe.transform(this.addToWishListResponse[i].products.created_at, 'mediumDate')
            });
          }
            this.cart.wishListData = this.addToWishListForUser;
          }
        })
      }
    })
  }

  addToChangingRoom(product: any) {
    let user = JSON.parse(localStorage.getItem('user'));
    if ((user && user.role == 'guest') || (this.cart.loginData && this.cart.loginData.role == 'guest')) {
      this.addChangingRoomForLocal(product);
    } else {
      this.addChangingRoomForUser(product);
    }
  }

  addChangingRoomForLocal(product: any) {
    let user = JSON.parse(localStorage.getItem('user'));
    let id = 'pcr|' + user.session_id;
    this.localPCRData = JSON.parse(localStorage.getItem(id));
    if (this.localPCRData == null) {
      localStorage.setItem(id, JSON.stringify([product]));
      this.localPCRData = JSON.parse(localStorage.getItem(id));
    } else {
      let item = this.localPCRData.filter((data: any) => data.id == product.id);
      if (item.length > 0) {
        this.localPCRData = this.localPCRData;
      } else {
        this.localPCRData.push(product);
      }
      localStorage.setItem(id, JSON.stringify(this.localPCRData));
    }
    this.cart.pcrData = this.localPCRData;
  }

  addChangingRoomForUser(product: any) {

  }

}

