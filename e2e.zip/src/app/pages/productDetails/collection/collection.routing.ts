import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CollectionComponent }  from './collection.component';

export const collectionroutes: Routes = [
  { path: '', component: CollectionComponent }
];

