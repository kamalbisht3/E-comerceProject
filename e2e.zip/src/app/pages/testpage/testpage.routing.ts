import { NgModule } from '@angular/core';
import { Routes } from '@angular/router';


import { TestpageComponent } from './testpage.component';

export const testpageRoutes: Routes = [
  { path: '', component:TestpageComponent },
]; 