import { Routes } from '@angular/router';
import { FaqComponent } from './faq.component';

export const FaqRoutes: Routes = [
  {
  	path: '',
  	component: FaqComponent
  }
];

