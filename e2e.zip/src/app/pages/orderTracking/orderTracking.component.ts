import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orderTracking',
  templateUrl: './orderTracking.component.html',
  styleUrls: ['./orderTracking.component.scss']
})
export class OrderTrackingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
