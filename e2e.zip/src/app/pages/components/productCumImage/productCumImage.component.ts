import { Component, OnInit, ChangeDetectionStrategy, Input } from '@angular/core';
import { Cart } from '../../../store/cart.store';
import { UserService } from '../../../services/user.service';
import { Constants } from '../../../api/constants';
import { SharedDataService } from '../../../services/shareData.service';
import { Router } from '@angular/router';
declare var $: any;
import { DatePipe } from '@angular/common';
@Component({
  selector: 'comp-productCumImage',
  templateUrl: './productCumImage.component.html',
  styleUrls: ['./productCumImage.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class ProductCumImageComponent implements OnInit {

  @Input() productName: string;
  @Input() productImagePath: string;
  @Input() productPrice: number;
  @Input() productDetail: any
  localCart: any = []
  localPCRData: any = []
  localWishList: any = []
  _ColorList = <any>[];
  _SizeList= <any>[];
  defaultColor : string;
  defaultSize: string;
  _ColorListResponse = <any>[];
  _SizeListResponse= <any>[];
  defaultColorResponse : string;
  defaultSizeResponse: string;
  defaultWishlistColor : string;
  defaultWishlistSize: string;
  _ColorWishListResponse = <any>[];
  _SizeWishListResponse= <any>[];
  addToWishListResponse = <any>[]; 
  id : any;
  price: any;
  name: any;
  thumbnail: any;
  created_at:any;
  UserCartList=<any>[];
  onSale:any;
  stockAmount:any;
  sku:any;
  discount:any;
  description:any;
  qty: any;
  totallength: number =0;
  UserProductList = <any>[];
  AddCartForUserList = <any>[];
  addToWishListForUser =<any>[];
  variation_id: string;
  variationId: string;
  constructor(private cart: Cart,
    private router: Router,
    private userService: UserService,
    private sharedDataService: SharedDataService,private datePipe: DatePipe) { }

  ngOnInit() {
  }

  goToProductDetail(id: string) {
    this.router.navigate(['/product-details', id])
  }

  addToCart(productItem) {
    // debugger;
    let user = JSON.parse(localStorage.getItem('user'))
    if ((user && user.role == 'guest') || (this.cart.loginData && this.cart.loginData.role == 'guest')) {
      this.addCartForLocal(productItem)
    } else {
      this.GetColorSize(productItem);
      if(this._ColorList.length > 0){
        // get default color
        this.defaultColor = this._ColorList[0].name;
      }
      if(this._SizeList.length > 0){
        // get default Size
        this.defaultSize = this._SizeList[0].name;
      }
      var obj = {
        "product_id": productItem.id,
        "variation_id": productItem.variations[0].id,
        "qty": 1,
        "Color":   this.defaultColor,
        "Size": this.defaultSize
        // "donation": this.charity
      };
      this.addCartForUser(obj)
    }
    $('.shopping-cart-component').removeClass('hide');      // For Open popup on add to cart.
  }

  GetColorSizeForUser(productDetail){
    this._ColorListResponse = [];
    this._SizeListResponse = [];
    for (let i = 0; i < productDetail.variations.variant_options.length; i++) {
      const uniqueSizeList=  this._SizeListResponse.filter(val => val.variant_id === productDetail.variations.variant_options[i].variant_id );
      if(uniqueSizeList.length === 0){
        if(this._SizeListResponse.length > 0){
          const uniqueColorList=  this._ColorListResponse.filter(val => val.variant_id === productDetail.variations.variant_options[i].variant_id );
          if(uniqueColorList.length === 0){
            this._ColorListResponse.push({variant_id:productDetail.variations.variant_options[i].variant_id,Color:productDetail.variations.variant_options[i].name });
          }
        } else {
          this._SizeListResponse.push({variant_id:productDetail.variations.variant_options[i].variant_id,Size:productDetail.variations.variant_options[i].name });
        }
       }
    }
  }

  addCartForUser(product) {
    this.userService.addCart(product).subscribe((response: any) => {
      if (response.status == Constants.success) {
        this.userService.getCart().subscribe((response: any) => {
          if (response.status == Constants.success) {
            this.AddCartForUserList= response.data;
            // const FilterValue = this.AddCartForUserList.filter(obj => obj.product_id === product.product_id );
            this.UserCartList = [];
            for(let i =0 ; i<this.AddCartForUserList.length; i++){
            const counter =1;
            this.GetColorSizeForUser(this.AddCartForUserList[i]);
            if(this._ColorListResponse.length > 0){
              // get default color
              this.defaultColorResponse = this._ColorListResponse[0].Color;
            }
            if(this._SizeListResponse.length > 0){
              // get default Size
              this.defaultSizeResponse = this._SizeListResponse[0].Size;
            }
            this.UserCartList.push({
              "product_id" :this.AddCartForUserList[i].product_id,
              "variation_id": this.AddCartForUserList[i].variation_id ,
             "products": {
               "name": this.AddCartForUserList[i].products.name,
               "product_id": this.AddCartForUserList[i].product_id,
               "thumbnail": this.AddCartForUserList[i].products.thumbnail,
               "Color": this.defaultColorResponse,
               "Size":this.defaultSizeResponse,
               "description": this.AddCartForUserList[i].products.description  ,
               "discount": this.AddCartForUserList[i].products.discount ,
               "onSale":this.AddCartForUserList[i].products.onSale,  
               "stockAmount": this.AddCartForUserList[i].products.stockAmount ,
               "created_at":  this.datePipe.transform(this.AddCartForUserList[i].products.created_at, 'mediumDate') 
             },
             "variations": {
               "sku": this.AddCartForUserList[i].variations.sku,
               "price": this.AddCartForUserList[i].variations.price,
             },
             // qty is used for no of product 
             "qty":this.AddCartForUserList[i].qty , 
             "Quantity" : counter
             // "donation": this.charity
           });
            }
            this.cart.cartData = this.UserCartList;
            this.sharedDataService.changeCart(this.UserCartList);
          }
        })
      }
    })
  }

  addCartForLocal(productItem) {
    debugger
    this.GetColorSize(productItem);
    if(this._ColorList.length > 0){
      // get default color
      this.defaultColor = this._ColorList[0].name;
    }
    if(this._SizeList.length > 0){
      // get default Size
      this.defaultSize = this._SizeList[0].name;
    }
    let obj = {
      "products": {
        "name": productItem.name,
        "product_id": productItem.id,
        "thumbnail": productItem.thumbnail,
        "Size":this.defaultSize,
        "Color":this.defaultColor
      },
      "variations": {
        "id": productItem.variations[0].id,
        "sku": productItem.variations[0].sku,
        "price": productItem.variations[0].price,
      },
      "id": productItem.id,
      "qty": 1,
      "Quantity" : 1
      // "donation": this.charity
    }
    let user = JSON.parse(localStorage.getItem('user'))
    this.localCart = JSON.parse(localStorage.getItem(user.session_id))
    if (this.localCart == null) {
      localStorage.setItem(user.session_id, JSON.stringify([obj]));
    } else {
      let item = this.localCart.filter((data: any) => data.id == productItem.id);
      if (item.length > 0) {
        item[0].qty++
        let i = item[0]
        this.localCart = this.localCart.filter(value => value.id != productItem.id);
        this.localCart.push(i);
      } else {
        this.localCart.push(obj);
      }
      localStorage.setItem(user.session_id, JSON.stringify(this.localCart));
    }
    this.cart.cartData = JSON.parse(localStorage.getItem(user.session_id));
    this.sharedDataService.changeCart(JSON.parse(localStorage.getItem(user.session_id)));
  }

  
  GetColorSize(productDetail){
    this._ColorList = [];
    this._SizeList = [];
    for (let i = 0; i < productDetail.variations.length; i++) {
      for (let j = 0; j < productDetail.variations[i].variant_options.length; j++) {
        if (productDetail.variants[0].id === productDetail.variations[i].variant_options[j].variant_id && productDetail.variants[0].type === 'color') {
          this._ColorList.push({ product_id: productDetail.variations[i].product_id, variationId: productDetail.variations[i].id, name: productDetail.variations[i].variant_options[j].name });
        }else{
          this._SizeList.push({product_id: productDetail.variations[i].product_id, variationId: productDetail.variations[i].id, name: productDetail.variations[i].variant_options[j].name})
        // for size code make new array for size
        }
      }
    }
  }

  addToWishList(product: any) {
    let user = JSON.parse(localStorage.getItem('user'))
    if ((user && user.role == 'guest') || (this.cart.loginData && this.cart.loginData.role == 'guest')) {
      this.addWishListForLocal(product);
    } else {
      this.addWishListForUser(product);
    }
  }

  // home page add item to wishlist
  addWishListForLocal(product: any) {
    this.GetColorSize(product);
    if(this._ColorList.length > 0){
      // get default color
      this.defaultColor = this._ColorList[0].name;
    }
    if(this._SizeList.length > 0){
      // get default Size
      this.defaultSize = this._SizeList[0].name;
    }
    this.localWishList= [];
    if(product.id !== undefined){
      this.id= product.id;
    }else{
      this.id= '';
    }
     if(product.thumbnail!== undefined){
      this.thumbnail =  product.thumbnail ;
     }else {
      this.thumbnail ='';
     }
     if(product.name!== undefined){
      this.name =   product.name ;
     }else{
      this.name = '';
     }
     if(product.variations[0].price !== undefined){
      this.price = product.variations[0].price 
     }else{
      this.price =0;
     }
     if(product.created_at !== undefined){
     // this.datePipe.transform(product.created_at, 'yyyy-MM-dd'); 
       this.created_at =  this.datePipe.transform(product.created_at, 'mediumDate'); // product.created_at;
     }else {
       this.created_at = '';
     }
     if(product.variations[0].sku !== undefined){
      this.sku = product.variations[0].sku 
     }else{
      this.sku =0;
     }
     if(product.variations[0].id !== undefined){
      this.variationId = product.variations[0].id ;
     }else{
      this.variationId ='';
     }
    let user = JSON.parse(localStorage.getItem('user'))
    let ids = 'wishlist|' + user.session_id
    this.localWishList = JSON.parse(localStorage.getItem(ids))
    if (this.localWishList == null) {
      this.localWishList= [];
      this.localWishList.push({ product_id: this.id,thumbnail:this.thumbnail,name:this.name,price:this.price
        , Color:this.defaultColor ,Size: this.defaultSize , created_at: this.created_at, 
        sku: this.sku ,id:this.variationId});
      localStorage.setItem(ids, JSON.stringify(this.localWishList));
      this.localWishList = JSON.parse(localStorage.getItem(ids));
    } else {
       let item = this.localWishList.filter((data: any) => data.id == product.id);   
      if (item.length === 0) {
        this.localWishList.push({ product_id: this.id,thumbnail:this.thumbnail,name:this.name,price:this.price
          , Color:this.defaultColor ,Size: this.defaultSize , created_at: this.created_at, 
          sku: this.sku ,id:this.variationId});
       } 
    
      localStorage.setItem(ids, JSON.stringify(this.localWishList));
    }
    this.cart.wishListData = this.localWishList;

    // let user = JSON.parse(localStorage.getItem('user'))
    // let id = 'wishlist|' + user.session_id
    // this.localWishList = JSON.parse(localStorage.getItem(id))
    // if (this.localWishList == null) {
    //   localStorage.setItem(id, JSON.stringify([product]))
    //   this.localWishList = JSON.parse(localStorage.getItem(id))
    // } else {
    //   let item = this.localWishList.filter((data: any) => data.id == product.id);
    //   if (item.length > 0) {
    //     this.localWishList = this.localWishList;
    //   } else {
    //     this.localWishList.push(product);
    //   }
    //   localStorage.setItem(id, JSON.stringify(this.localWishList))
    // }
    // this.cart.wishListData = this.localWishList;
  }

  GetColorSizeForWishListUser(productDetail){
    this._ColorWishListResponse = [];
    this._SizeWishListResponse = [];
    for (let i = 0; i < productDetail.variations.variation_variant_options.length; i++) {
      const uniqueSizeList=  this._SizeWishListResponse.filter(val => val.variant_id === productDetail.variations.variation_variant_options[i].option.variant_id );
      if(uniqueSizeList.length === 0){
        if(this._SizeWishListResponse.length > 0){
          const uniqueColorList=  this._ColorWishListResponse.filter(val => val.variant_id === productDetail.variations.variation_variant_options[i].option.variant_id );
          if(uniqueColorList.length === 0){
            this._ColorWishListResponse.push({variant_id: productDetail.variations.variation_variant_options[i].option.variant_id,Color:productDetail.variations.variation_variant_options[i].option.name });
          }
        } else {
          this._SizeWishListResponse.push({variant_id: productDetail.variations.variation_variant_options[i].option.variant_id,Size: productDetail.variations.variation_variant_options[i].option.name });
        }
       }
    }
  }

  addWishListForUser(product: any) {
    let obj = {
      "product_id": product.id,
      "variation_id": product.variations[0].id
    }
    this.userService.addToWishList(obj).subscribe((response: any) => {
      if (response.status == Constants.success) {
        this.userService.getWishList().subscribe((response: any) => {
          if (response.status == Constants.success) {
            this.addToWishListResponse = response.data;
            this.addToWishListForUser= [];
            for(let i =0 ; i<this.addToWishListResponse.length; i++){
            this.GetColorSizeForWishListUser(this.addToWishListResponse[i]);
            if(this._ColorWishListResponse.length > 0){
              // get default color
              this.defaultWishlistColor = this._ColorWishListResponse[0].Color;
            }
            if(this._SizeWishListResponse.length > 0){
              // get default Size
              this.defaultWishlistSize = this._SizeWishListResponse[0].Size;
            }         
             this.addToWishListForUser.push({ product_id: this.addToWishListResponse[i].product_id,
              id: this.addToWishListResponse[i].product_id,
              thumbnail:this.addToWishListResponse[i].products.thumbnail,
              name:this.addToWishListResponse[i].products.name,
              price:this.addToWishListResponse[i].variations.price,
              Color: this.defaultWishlistColor ,
              Size: this.defaultWishlistSize ,
              sku:this.addToWishListResponse[i].variations.sku,
              variation_id:this.addToWishListResponse[i].variations.id,
              created_at: this.datePipe.transform(this.addToWishListResponse[i].products.created_at, 'mediumDate')
            });
          }
            this.cart.wishListData = this.addToWishListForUser;
          }
        })
      }
    })
  }

  addToChangingRoom(product: any) {
    let user = JSON.parse(localStorage.getItem('user'))
    if ((user && user.role == 'guest') || (this.cart.loginData && this.cart.loginData.role == 'guest')) {
      this.addChangingRoomForLocal(product);
    } else {
      this.addChangingRoomForUser(product);
    }
  }

  addChangingRoomForLocal(product: any) {
    let user = JSON.parse(localStorage.getItem('user'))
    let id = 'pcr|' + user.session_id
    this.localPCRData = JSON.parse(localStorage.getItem(id))
    if (this.localPCRData == null) {
      localStorage.setItem(id, JSON.stringify([product]))
      this.localPCRData = JSON.parse(localStorage.getItem(id))
    } else {
      let item = this.localPCRData.filter((data: any) => data.id == product.id)
      if (item.length > 0) {
        this.localPCRData = this.localPCRData
      } else {
        this.localPCRData.push(product)
      }
      localStorage.setItem(id, JSON.stringify(this.localPCRData))
    }
    this.cart.pcrData = this.localPCRData
  }

  addChangingRoomForUser(product: any) {

  }
}
