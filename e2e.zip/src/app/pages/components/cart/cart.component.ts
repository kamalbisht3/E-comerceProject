import { Component, OnInit } from '@angular/core'
import * as $ from 'jquery';
import { UserService } from '../../../services/user.service';
import { Router } from '@angular/router';
import { SharedDataService } from '../../../services/shareData.service';
import { Constants } from '../../../api/constants';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LoginComponent } from '../../login/login.component';
import { Cart } from '../../../store/cart.store';
import { DatePipe } from '@angular/common';
@Component({
    selector: 'app-cart-window',
    templateUrl: './cart.component.html',
    styleUrls: ['./cart.component.scss']
})

export class CartComponent implements OnInit {
    cart: Array<any> =[];
    cartLength: number = 0;
    user: any;
    totalAmount: number
    localCart: Array<any> = [];
    Color:string;
    Size:string;
    product_id:string;
    _ColorListResponse = <any>[];
    _SizeListResponse= <any>[];
    defaultColorResponse : string;
    defaultSizeResponse: string;
    UserCartList=<any>[];
    id : any;
    price: any;
    name: any;
    thumbnail: any;
    created_at:any;
    onSale:any;
    stockAmount:any;
    sku:any;
    discount:any;
    description:any;
    qty: any;
    totallength: number =0;
    UserProductList = <any>[];
    AddCartForUserList = <any>[];
    variation_id: string;
    selectedSize: string;
    selectedColor: string;
    selectedThumbnail: string;
    defaultThumbnail: string;
    _UserCartList = <any>[];
    uniqueCartData = <any>[];
    constructor(private userService: UserService,
        private router: Router,
        private sharedCartData: SharedDataService,private datePipe: DatePipe,
        private modalService: NgbModal,
        private cartService: Cart) { }

    ngOnInit() {
        debugger;
        this.sharedCartData.currentCart.subscribe((sharedData: any) => {
            debugger;
            this.cart = sharedData;
            this.cartService.cartData = this.cart;
            this.totalAmount = this.getTotalAmount(this.cart);
            this.cartLength = this.cart.length;           
        });
        this.user = JSON.parse(localStorage.getItem('user')); 
        if (this.user && this.user.role == 'guest') {
            this.cart = JSON.parse(localStorage.getItem(this.user.session_id))
            this.cartService.cartData = this.cart
            this.totalAmount = this.getTotalAmount(this.cart);
            this.cartLength = this.cart.length;
        } else {
            this.getCart();
            // this.sharedCartData.currentCart.subscribe((sharedData: any) => {
            //     debugger;
            //     this.cart = sharedData;
            //     this.cartService.cartData = this.cart;
            //     this.totalAmount = this.getTotalAmount(this.cart);
            //     this.cartLength = this.cart.length;
            // })
        }

       // console.log('Cart Data ---->', JSON.stringify(this.cart));

    }

     getCart() {
         debugger;
        this.userService.getCart().subscribe((response: any) => {
            if (response.status == Constants.success) {
                debugger
                this.AddCartForUserList=  response.data;
                if(this.AddCartForUserList.length > 0){
                for(let i =0 ; i<this.AddCartForUserList.length; i++){
                const counter =1;
                this.GetColorSizeForUser(this.AddCartForUserList[i]);
                if(this._ColorListResponse.length > 0){
                  // get default color
                  this.defaultColorResponse = this._ColorListResponse[0].Color;
                }
                if(this._SizeListResponse.length > 0){
                  // get default Size
                  this.defaultSizeResponse = this._SizeListResponse[0].Size;
                }
           
                this.UserCartList.push({
                    "product_id" :this.AddCartForUserList[i].product_id,
                    "variation_id": this.AddCartForUserList[i].variation_id ,
                   "products": {
                     "name": this.AddCartForUserList[i].products.name,
                     "product_id": this.AddCartForUserList[i].product_id,
                     "thumbnail": this.AddCartForUserList[i].products.thumbnail,
                     "Color": this.defaultColorResponse,
                     "Size":this.defaultSizeResponse,
                     "description": this.AddCartForUserList[i].products.description  ,
                     "discount": this.AddCartForUserList[i].products.discount ,
                     "onSale":this.AddCartForUserList[i].products.onSale,  
                     "stockAmount": this.AddCartForUserList[i].products.stockAmount ,
                     "created_at":  this.datePipe.transform(this.AddCartForUserList[i].products.created_at, 'mediumDate') 
                   },
                   "variations": {
                     "sku": this.AddCartForUserList[i].variations.sku,
                     "price": this.AddCartForUserList[i].variations.price,
                   },
                   // qty is used for no of product 
                   "qty":this.AddCartForUserList[i].qty , 
                   "Quantity" : counter
                   // "donation": this.charity
                 });
                }
                this.cart =this.UserCartList;
                this.cartService.cartData = this.cart
                this.totalAmount = this.getTotalAmount(this.cart);
                this.cartLength = this.cart.length;
              }            
            }
        });
    }

    increaseItemQty(product: any) {
        debugger;
        if ((this.user && this.user.role == 'guest') || (this.cartService.loginData && this.cartService.loginData.role == 'guest')) {
            let user = JSON.parse(localStorage.getItem('user'))
            let localCart = JSON.parse(localStorage.getItem(user.session_id))
            let item = localCart.filter((data: any) => data.id == product.id)
            if (item.length > 0) {
                item[0].qty++
              //  let i = item[0]
              //  localCart = localCart.filter(value => value.id != product.id)
              //  localCart.push(item[0])
                localStorage.setItem(user.session_id, JSON.stringify(localCart))
                this.cart = localCart
                this.cartService.cartData = this.cart
                this.totalAmount = this.getTotalAmount(this.cart);
                this.cartLength = this.cart.length;
            }
        } else {
            var obj = {
                "product_id": product.product_id,
                "variation_id": product.variations.id,
                "qty": 1,
                "donation": 0,

            };
            this.addCartToForUser(obj)
        }
    }

    decreaseItemQty(product: any) {
        debugger;
        if ((this.user && this.user.role == 'guest') || (this.cartService.loginData && this.cartService.loginData.role == 'guest')) {
            let user = JSON.parse(localStorage.getItem('user'))
            let localCart = JSON.parse(localStorage.getItem(user.session_id))
            let item = localCart.filter((data: any) => data.id == product.id)
            if (item.length > 0 && item[0].qty > 1) {
                item[0].qty--
              //  let i = item[0]
              //  localCart = localCart.filter(value => value.id != product.id)
              //  localCart.push(i)
                localStorage.setItem(user.session_id, JSON.stringify(localCart))
                this.cart = localCart
                this.cartService.cartData = this.cart
                this.totalAmount = this.getTotalAmount(this.cart);
                this.cartLength = this.cart.length;
            } else this.removeCartItem(product)
        } else {
            var obj = {
                "product_id": product.product_id,
                "variation_id": product.variations.id,
                "qty": -1,
                "donation": 0,
            };
            this.addCartToForUser(obj)
        }
    }

    addCartToForUser(product) {
        debugger;
        this.userService.addCart(product).subscribe((data: any) => {
            debugger;
            if (data.status == Constants.success) {
                this.userService.getCart().subscribe((data: any) => {
                    if (data.status == Constants.success) {
                        debugger;
                         this.AddCartForUserList= data.data;
                        this.UserCartList = [];
                        for(let i =0 ; i<this.AddCartForUserList.length; i++){
                        const counter =1;
                        this.GetColorSizeForUser(this.AddCartForUserList[i]);
                        if(this._ColorListResponse.length > 0){
                          // get default color
                          this.defaultColorResponse = this._ColorListResponse[0].Color;
                        }
                        if(this._SizeListResponse.length > 0){
                          // get default Size
                          this.defaultSizeResponse = this._SizeListResponse[0].Size;
                        }
                        this.UserCartList.push({
                            "product_id" :this.AddCartForUserList[i].product_id,
                            "variation_id": this.AddCartForUserList[i].variation_id ,
                           "products": {
                             "name": this.AddCartForUserList[i].products.name,
                             "product_id": this.AddCartForUserList[i].product_id,
                             "thumbnail": this.AddCartForUserList[i].products.thumbnail,
                             "Color": this.defaultColorResponse,
                             "Size":this.defaultSizeResponse,
                             "description": this.AddCartForUserList[i].products.description  ,
                             "discount": this.AddCartForUserList[i].products.discount ,
                             "onSale":this.AddCartForUserList[i].products.onSale,  
                             "stockAmount": this.AddCartForUserList[i].products.stockAmount ,
                             "created_at":  this.datePipe.transform(this.AddCartForUserList[i].products.created_at, 'mediumDate') 
                           },
                           "variations": {
                             "sku": this.AddCartForUserList[i].variations.sku,
                             "price": this.AddCartForUserList[i].variations.price,
                           },
                           // qty is used for no of product 
                           "qty":this.AddCartForUserList[i].qty , 
                           "Quantity" : counter
                           // "donation": this.charity
                         });
                        }
                        this.cartService.cartData =  this.UserCartList;
                        this.sharedCartData.changeCart(this.UserCartList);
                    }
                })
            }
        });
    }

    GetColorSizeForUser(productDetail){
        this._ColorListResponse = [];
        this._SizeListResponse = [];
        for (let i = 0; i < productDetail.variations.variant_options.length; i++) {
          const uniqueSizeList=  this._SizeListResponse.filter(val => val.variant_id === productDetail.variations.variant_options[i].variant_id );
          if(uniqueSizeList.length === 0){
            if(this._SizeListResponse.length > 0){
              const uniqueColorList=  this._ColorListResponse.filter(val => val.variant_id === productDetail.variations.variant_options[i].variant_id );
              if(uniqueColorList.length === 0){
                this._ColorListResponse.push({variant_id:productDetail.variations.variant_options[i].variant_id,Color:productDetail.variations.variant_options[i].name });
              }
            } else {
              this._SizeListResponse.push({variant_id:productDetail.variations.variant_options[i].variant_id,Size:productDetail.variations.variant_options[i].name });
            }
           }
        }
      }

    removeCartItem(product: any) {
        debugger
        if ((this.user && this.user.role == 'guest') || (this.cartService.loginData && this.cartService.loginData.role == 'guest')) {
            let user = JSON.parse(localStorage.getItem('user'))
            let localCart = JSON.parse(localStorage.getItem(user.session_id))
            localCart = localCart.filter(value => value.id != product.id)
            localStorage.setItem(user.session_id, JSON.stringify(localCart))
            this.cart = localCart
            this.cartService.cartData = this.cart
            this.totalAmount = this.getTotalAmount(this.cart)
            this.cartLength = this.cart.length;
        } else {
            let id = product.variation_id
            this.userService.deleteCartItem(id).subscribe((response: any) => {
                debugger;
                if (response.status == Constants.success) {
                    this.cart = this.cart.filter((filterValue: any) => filterValue.variation_id != id)
                    this.cartService.cartData = this.cart
                    this.totalAmount = this.getTotalAmount(this.cart);
                    this.cartLength = this.cart.length;
                }
            })
        }
    }

    getTotalAmount(cart: any) {

        this.totalAmount = 0
        if (cart) {
        // const qty = cart.qty;
        // const price =cart.variations.price;
        // this.totalAmount = this.totalAmount + (qty * price);
            cart.forEach(element => {
              
                this.totalAmount = this.totalAmount + (element.qty * element.variations.price)
            });
         }
        return this.totalAmount
    }

    openLoginModal() {
        const modalRef = this.modalService.open(LoginComponent);
        modalRef.result.then(() => {
            this.getCart()
            this.closeCart()
        })
    }

    moveToCheckout() {
        $('.shopping-cart-component').addClass('hide');
        this.router.navigate(['/payment'])
        localStorage.setItem('CartDetail', JSON.stringify(this.cart));
        localStorage.setItem('SubTotal', JSON.stringify(this.totalAmount));
    }

    closeCart() {
        $('.shopping-cart-component').addClass('hide');
    }
}