import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { Constants } from '../../api/constants';
import { Cart } from '../../store/cart.store';
import { SharedDataService } from '../../services/shareData.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.scss']
})
export class WishlistComponent implements OnInit {
  wishList: any
  WishListLength: number = 0;
  user: any
  localCart: any
  Quantity: number = 1;
  Qty: Array<any> = [];
  defaultWishlistColor : string;
  defaultWishlistSize: string;
  _ColorWishListResponse = <any>[];
  _SizeWishListResponse= <any>[];
  addToWishListResponse =<any>[];
  _ColorListResponse = <any>[];
  _SizeListResponse= <any>[];
  AddCartForUserList =<any>[];
  UserCartList =<any>[];
  defaultColorResponse : string;
  defaultSizeResponse: string;
  _getwishlist =<any>[];
  AfterAddToCart = <any>[];
  constructor(private userService: UserService,
    public router: Router,
      private sharedDataService: SharedDataService,private datePipe: DatePipe,
      private cart: Cart) { }



  ngOnInit() {
    debugger
    if(localStorage.getItem('user')) {
      this.user = JSON.parse(localStorage.getItem('user'))
      if(this.user.role == 'guest' && localStorage.getItem('wishlist|' + this.user.session_id)) {
        debugger;
        this.wishList = JSON.parse(localStorage.getItem('wishlist|' + this.user.session_id));
        debugger;
        this.WishListLength = this.wishList.length;
        this.cart.wishListData = this.wishList
        debugger;
        // console.log(this.cart.wishListData);
      } else {
        this.getWishList()
      }
    }
  }

  getWishList() {
    debugger;
    // after wishlist is add to cart
    this.AfterAddToCart = JSON.parse(localStorage.getItem('wishlistData'));
    if(this.AfterAddToCart !== null){
      this.wishList= [];
      for(let i =0 ; i<this.AfterAddToCart.length; i++){
      this.wishList.push({ product_id: this.AfterAddToCart[i].product_id,
        id: this.AfterAddToCart[i].id,
        thumbnail:this.AfterAddToCart[i].thumbnail,
        name:this.AfterAddToCart[i].name,
        price:this.AfterAddToCart[i].price,
        Color: this.AfterAddToCart[i].Color ,
        Size: this.AfterAddToCart[i].Size ,
        sku:this.AfterAddToCart[i].sku,
        variation_id:this.AfterAddToCart[i].variation_id,
        created_at: this.datePipe.transform(this.AfterAddToCart[i].created_at, 'mediumDate')
      });
    }
    this.WishListLength = this.wishList.length;
    this.cart.wishListData =this.wishList;
    // local storage is used when add data to AddToCart
    localStorage.setItem('wishlistData' , JSON.stringify(this.wishList));
    } else{
    this.userService.getWishList().subscribe((response: any) => {
      if(response.status == Constants.success) {
         debugger;
      //  this.wishList = response.data
        this.addToWishListResponse =  response.data;
        this.wishList= [];
        for(let i =0 ; i<this.addToWishListResponse.length; i++){
        this.GetColorSizeForWishListUser(this.addToWishListResponse[i]);
        if(this._ColorWishListResponse.length > 0){
          // get default color
          this.defaultWishlistColor = this._ColorWishListResponse[0].Color;
        }
        if(this._SizeWishListResponse.length > 0){
          // get default Size
          this.defaultWishlistSize = this._SizeWishListResponse[0].Size;
        }         
         this.wishList.push({ product_id: this.addToWishListResponse[i].product_id,
          id: this.addToWishListResponse[i].product_id,
          thumbnail:this.addToWishListResponse[i].products.thumbnail,
          name:this.addToWishListResponse[i].products.name,
          price:this.addToWishListResponse[i].variations.price,
          Color: this.defaultWishlistColor ,
          Size: this.defaultWishlistSize ,
          sku:this.addToWishListResponse[i].variations.sku,
          variation_id:this.addToWishListResponse[i].variations.id,
          created_at: this.datePipe.transform(this.addToWishListResponse[i].products.created_at, 'mediumDate')
        });
      }
        this.WishListLength = this.wishList.length;
        this.cart.wishListData =this.wishList;
        // local storage is used when add data to AddToCart
        localStorage.setItem('wishlistData' , JSON.stringify(this.wishList));
      }
    });
  }
  }

  GetColorSizeForWishListUser(productDetail){
    this._ColorWishListResponse = [];
    this._SizeWishListResponse = [];
    for (let i = 0; i < productDetail.variations.variation_variant_options.length; i++) {
      const uniqueSizeList=  this._SizeWishListResponse.filter(val => val.variant_id === productDetail.variations.variation_variant_options[i].option.variant_id );
      if(uniqueSizeList.length === 0){
        if(this._SizeWishListResponse.length > 0){
          const uniqueColorList=  this._ColorWishListResponse.filter(val => val.variant_id === productDetail.variations.variation_variant_options[i].option.variant_id );
          if(uniqueColorList.length === 0){
            this._ColorWishListResponse.push({variant_id: productDetail.variations.variation_variant_options[i].option.variant_id,Color:productDetail.variations.variation_variant_options[i].option.name });
          }
        } else {
          this._SizeWishListResponse.push({variant_id: productDetail.variations.variation_variant_options[i].option.variant_id,Size: productDetail.variations.variation_variant_options[i].option.name });
        }
       }
    }
  }

  getPCRData() {
    if (localStorage.getItem('user')) {
      let user = JSON.parse(localStorage.getItem('user'))
      if (user.role == 'guest' && localStorage.getItem('pcr|' + user.session_id)) {
        let pcrList = JSON.parse(localStorage.getItem('pcr|' + user.session_id))
        this.cart.pcrData = pcrList
      } else {
        // this.userService.getWishList().subscribe((response: any) => {
        //   if (response.status == Constants.success) {
        //     this.cart.pcrData = response.data
        //   }
        // })
      }
    }
  }
  editWishListItem(id: string){
    this.router.navigateByUrl('/product-details/' + id);
  }


  removeWishListItem(_id) {
    debugger;
    if(localStorage.getItem('user')) {
      this.user = JSON.parse(localStorage.getItem('user'))
      if(this.user.role == 'guest' && localStorage.getItem('wishlist|' + this.user.session_id)) {
        this.wishList = JSON.parse(localStorage.getItem('wishlist|' + this.user.session_id))
        this.wishList = this.wishList.filter((filterData: any) => filterData.id != _id)
        localStorage.setItem('wishlist|' + this.user.session_id, JSON.stringify(this.wishList))
        this.cart.wishListData = this.wishList
        this.WishListLength = this.wishList.length;
      } else {
        this._getwishlist = JSON.parse(localStorage.getItem('wishlistData'));
        this.wishList = this._getwishlist.filter((filterData: any) => filterData.id != _id);
        this.cart.wishListData = this.wishList
        this.WishListLength = this.wishList.length;
        localStorage.setItem('wishlistData', JSON.stringify(this.wishList))
        // this.userService.deleteWishListItem(_id).subscribe((response: any) => {
        //   debugger
        //   if(response.status == Constants.success) {
        //     this.wishList = this.wishList.filter((filterData: any) => filterData.id != _id)
        //     this.cart.wishListData = this.wishList
        //     this.WishListLength = this.wishList.length;
        //   }
        // });
      }
    }
  }
  qtyAddToCart(productItem) {
    this.addToCart(productItem);
  }

  addToCart(productItem) {
    debugger;
    let user = JSON.parse(localStorage.getItem('user'))
    if ((user && user.role == 'guest') || (this.cart.loginData && this.cart.loginData.role == 'guest')) {
      this.addCartForLocal(productItem)
    } else {
      var obj = {
        "product_id": productItem.product_id,
        "variation_id": productItem.variation_id,
        "qty": 1,
        "donation": 0
      };
      this.addCartForUser(obj, productItem.id)
    }
  }

  GetColorSizeForUser(productDetail){
    this._ColorListResponse = [];
    this._SizeListResponse = [];
    for (let i = 0; i < productDetail.variations.variant_options.length; i++) {
      const uniqueSizeList=  this._SizeListResponse.filter(val => val.variant_id === productDetail.variations.variant_options[i].variant_id );
      if(uniqueSizeList.length === 0){
        if(this._SizeListResponse.length > 0){
          const uniqueColorList=  this._ColorListResponse.filter(val => val.variant_id === productDetail.variations.variant_options[i].variant_id );
          if(uniqueColorList.length === 0){
            this._ColorListResponse.push({variant_id:productDetail.variations.variant_options[i].variant_id,Color:productDetail.variations.variant_options[i].name });
          }
        } else {
          this._SizeListResponse.push({variant_id:productDetail.variations.variant_options[i].variant_id,Size:productDetail.variations.variant_options[i].name });
        }
       }
    }
  }

  addCartForUser(product, id) {
    debugger;
    this.removeWishListItem(id)
    this.userService.addCart(product).subscribe((response: any) => {
      if (response.status == Constants.success) {
        this.userService.getCart().subscribe((response: any) => {
          if (response.status == Constants.success) {
            debugger;
            this.AddCartForUserList= response.data;
            // const FilterValue = this.AddCartForUserList.filter(obj => obj.product_id === product.product_id );
            this.UserCartList = [];
            for(let i =0 ; i<this.AddCartForUserList.length; i++){
            const counter =1;
            this.GetColorSizeForUser(this.AddCartForUserList[i]);
            if(this._ColorListResponse.length > 0){
              // get default color
              this.defaultColorResponse = this._ColorListResponse[0].Color;
            }
            if(this._SizeListResponse.length > 0){
              // get default Size
              this.defaultSizeResponse = this._SizeListResponse[0].Size;
            }
             this.UserCartList.push({
               "product_id" :this.AddCartForUserList[i].product_id,
               "variation_id": this.AddCartForUserList[i].variation_id ,
              "products": {
                "name": this.AddCartForUserList[i].products.name,
                "product_id": this.AddCartForUserList[i].product_id,
                "thumbnail": this.AddCartForUserList[i].products.thumbnail,
                "Color": this.defaultColorResponse,
                "Size":this.defaultSizeResponse,
                "description": this.AddCartForUserList[i].products.description  ,
                "discount": this.AddCartForUserList[i].products.discount ,
                "onSale":this.AddCartForUserList[i].products.onSale,  
                "stockAmount": this.AddCartForUserList[i].products.stockAmount ,
                "created_at":  this.datePipe.transform(this.AddCartForUserList[i].products.created_at, 'mediumDate') 
              },
              "variations": {
                "sku": this.AddCartForUserList[i].variations.sku,
                "price": this.AddCartForUserList[i].variations.price,
              },
              // qty is used for no of product 
              "qty":this.AddCartForUserList[i].qty , 
              "Quantity" : counter
              // "donation": this.charity
            });
            }
            this.cart.cartData = this.UserCartList;
            this.sharedDataService.changeCart( this.UserCartList);
          }
        })
      }
    })
  }

  addCartForLocal(productItem) {
    debugger;
    this.removeWishListItem(productItem.id)
    let obj = {
      "products": {
        "name": productItem.name,
        "product_id": productItem.product_id,
        "thumbnail": productItem.thumbnail,
        "Color": productItem.Color,
        "Size":productItem.Size
      },
      "variations": {
        "id": productItem.id,
        "sku": productItem.sku,
        "price": productItem.price,
      },
      "id": productItem.product_id,
      "qty":1 ,
      "Quantity" : 1,
      "donation": 0
    }
    let user = JSON.parse(localStorage.getItem('user'));
    this.localCart = JSON.parse(localStorage.getItem(user.session_id));
    if (this.localCart == null) {
      localStorage.setItem(user.session_id, JSON.stringify([obj]));
    } else {
      let item = this.localCart.filter((data: any) => data.id == productItem.id);
      if (item.length > 0) {
        item[0].qty = item[0].qty + this.Quantity;
        let i = item[0]
        this.localCart = this.localCart.filter(value => value.id != productItem.id);
        this.localCart.push(i);
      } else {
        this.localCart.push(obj);
      }
      localStorage.setItem(user.session_id, JSON.stringify(this.localCart));
    }
    this.cart.cartData = JSON.parse(localStorage.getItem(user.session_id));
    this.sharedDataService.changeCart(JSON.parse(localStorage.getItem(user.session_id)));
  }

  IncrementValue(Quantity) {

    if (Quantity <= 9 && Quantity >= 1) {
      this.Quantity = this.Quantity + 1;
    }

  }
  DecrementValue(Quantity) {

    if (Quantity <= 10 && Quantity > 1) {
      this.Quantity = this.Quantity - 1;
    }
  }  
}
export interface Options{
  key:  number;
  value: string;
}
