import { Routes } from '@angular/router';
import { EthicalTradingComponent } from './ethicalTrading.component';

export const EthicalTradingRoutes: Routes = [
  {
  	path: '',
  	component: EthicalTradingComponent
  }
];

