import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-termsConditions',
  templateUrl: './termsConditions.component.html',
  styleUrls: ['./termsConditions.component.scss']
})
export class TermsConditionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
