import {Routes} from '@angular/router'
import { TermsConditionsComponent } from './termsConditions.component';

export const tmRoute: Routes = [
    {
        path: '',
        component: TermsConditionsComponent
    }
]