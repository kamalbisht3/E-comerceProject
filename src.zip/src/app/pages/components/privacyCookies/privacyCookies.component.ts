import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-privacyCookies',
  templateUrl: './privacyCookies.component.html',
  styleUrls: ['./privacyCookies.component.scss']
})
export class PrivacyCookiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
