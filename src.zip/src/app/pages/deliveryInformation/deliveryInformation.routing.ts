import { Routes } from '@angular/router';
// import { DeliveryInformationComponent } from './'
import { DeliveryInformationComponent } from './deliveryInformation.component';

export const diRoutes: Routes = [
  {
  	path: '',
  	component: DeliveryInformationComponent
  }
];

