import { NgModule } from '@angular/core';
import { Routes } from '@angular/router';

import { RecentlyViewedComponent } from './recentlyViewed.component';

export const recenltyViewedroutes: Routes = [
  { path: '', component: RecentlyViewedComponent },
];

