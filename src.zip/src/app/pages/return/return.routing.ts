import { Routes } from '@angular/router';
import { ReturnComponent } from './return.component';

export const ReturnRoutes: Routes = [
  {
  	path: '',
  	component: ReturnComponent
  }
];

