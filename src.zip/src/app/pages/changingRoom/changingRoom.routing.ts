import {Routes} from '@angular/router'
import { ChangingRoomComponent } from './changingRoom.component';

export const route: Routes = [
    {
        path: '',
        component: ChangingRoomComponent
    }
]