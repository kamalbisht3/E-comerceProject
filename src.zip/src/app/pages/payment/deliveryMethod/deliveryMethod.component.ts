import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'payment-deliveryMethod',
  templateUrl: './deliveryMethod.component.html',
  styleUrls: ['./deliveryMethod.component.css']
})
export class DeliveryMethodComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
