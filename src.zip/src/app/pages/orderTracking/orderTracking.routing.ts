import { Routes } from '@angular/router';
import { OrderTrackingComponent } from './orderTracking.component';

export const otRoutes: Routes = [
  {
  	path: '',
  	component: OrderTrackingComponent
  }
];

